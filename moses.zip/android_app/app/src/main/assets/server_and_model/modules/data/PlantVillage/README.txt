Download and place the data directory here for training and testing. Training data available to download at: https://github.com/MarkoArsenovic/DeepLearning_PlantDiseases

Reference:
[1]. B. Mohammed, A. Marko, L. Sohaib, S. Srdjan, B. Kamel, and M. Abdelouhab, "Deep Learning for Plant Diseases: Detection and Saliency Map Visualisation", Book: "Human and Machine Learning: Visible, Explainable, Trustworthy and Transparent", Springer International Publishing, p. 93-117, 2018.
